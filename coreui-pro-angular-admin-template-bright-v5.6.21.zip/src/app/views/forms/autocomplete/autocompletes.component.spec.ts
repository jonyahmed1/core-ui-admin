import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AutocompletesComponent } from './autocompletes.component';
import { provideRouter } from '@angular/router';
import { IconSetService } from '@coreui/icons-angular';
import { iconSubset } from '../../../icons/icon-subset';

describe('AutocompleteComponent', () => {
  let component: AutocompletesComponent;
  let fixture: ComponentFixture<AutocompletesComponent>;
  let iconSetService: IconSetService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AutocompletesComponent],
      providers: [provideRouter([]), IconSetService]
    })
    .compileComponents();

    iconSetService = TestBed.inject(IconSetService);
    iconSetService.icons = { ...iconSubset };

    fixture = TestBed.createComponent(AutocompletesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
